 # Workbook for Udaciracer project
 
## Task 1 - Initialise the environment
- [x] Fork the udacity repo
- [x] Clone the udacity repo
- [x] create new branch for development
- [x] Check you have all expected files
- [x] Change ports to 8080
- [x] Start server (API)
- [x] Start server (Localhost:8080)

## Task 2 - Architecture
- [x] Breakdown the architecture
- [x] Code walk through
- [x] Draw a top level diagram overview

## Task 3 - API calls

- [x] Read through the instructions for the API calls
- [x] Examine the fetch in server/index.js
- [x] Examine the fetches in client/assests.javascript/index.js
- [x] Draw a top level diagram overview
- [x] recreate the existing API call in server/index.js for all partials
- [x] test the new fetches

## Task 4 - Select Track and racers

- [x] create fetch `getTracks()`
- [x] create fetch `getRacers()`
- [x] test the new fetches
- [x] render html `renderTrackCards()`
- [x] render html `renderRacerCard()`

## Task 5 - add track and racer to the store

- [x] save selected track to the store `handleSelectTrack`
        `store.track_id = target.id;`

- [x] save selected racer to the store `handleSelectPodRacer`
        `store.player_id = target.id;`


## Task 6 - create the race

- [x] render starting UI `handleCreateRace()`
        `renderAt('#race', renderRaceStartView())`  

- [x] invoke API to create race and save result `const race =`
- [x] Update store with race id
        `let track_id = store.track_id;`

- [x] Update store with race_id

     `store race_id = target.ID`

- [x] Create alert to notify user they have not made their selections

- [ ] Ensure selected race is shown in header 
        Issue here track.name always shows as track 1???

## Task 7 - The Countdown

- [x] call the async functions runCountdown(), startRace() and runRace()
- [x] setInterval() to countdown once per second `runCountdown()`
```Invoke the API call to accelerate	 setInterval(() => {
		 if (timer > 0) {
```

- [x] When countdown complete clear interval 
        `clearInterval()`
- [x] Resolve promise and return
        `resolve()`
		

## Task 8 - runRace()

- [x] setInterval() to get race info every 500ms
	`const interval = setInterval(async () => {`
- [x] Update the leaderboard if the race is in progress
- [x] When race complete stop interval from repeating
        ` clearInterval(interval);`
- [x] Render results
        ` renderAt("#race", resultsView(raceInfo.positions));`

## Task 9 - handleAccelerate()

- [x] Invoke the API call to accelerate
```
	try{
		await accelerate(store.race_id)
	} catch(error) {
		console.log("Problem with handleCountdown:", error.message);

	}
}
```
